#!/bin/ksh

#----------------
# Setup parameters
#----------------
LBS_FS="/home/padmin/vios_nmon"
NMONLOG=${LBS_FS}
EXEPATH=${LBS_FS}

if [ -d "/home/padmin" ]
then
	NMONLOG=${LBS_FS}
	EXEPATH=${LBS_FS}
else
	NMONLOG=/tmp/ibmlst/nmon/logs
	EXEPATH=/tmp/ibmlst/nmon/scripts	
	
fi

cd $NMONLOG
/usr/bin/nmon -F `hostname`_5m_D_`date \+%d`.nmon -dAOPV^MT -s 300 -c 288
#/usr/bin/nmon -F `hostname`_1m_D_`date \+%d`.nmon -dAOPV^MT -s 60 -c 1440

